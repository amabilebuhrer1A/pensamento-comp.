// o homem aranha no aranhaverso,10 anos+,animação,ação,comédia,super-herói
// a princesa kaguya,9 anos+,animação,anime,filme musical,infantil
// vidas ao vento,12 anos,anime,animação,romance,guerra
// meu amigo totoro,livre,fantasia,drama e aventura
// castelo animado,11 anos+,anime,animação,romance,infantil
// o serviços de entrega da kiki,livre,animação,anime
// digital circus,livre,humor negro,ficção científica,drama
// black mirror,16 anos,ficção científica,sátira e drama psicológico
// sweet tooth,livre,ação,ficção pós-apocalíptica,,fantasia,aventura
// homem aranha:através do aranhaverso,livre,ação,fantasia,ficção científica e super-heróis
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let campoIdade;
let campoFantasia;
let campoAventura;

function setup() {
  createCanvas(800, 400);
  createElement("h2", "Recomendador de filmes");
  createSpan("Sua idade:");
  campoIdade = createInput("5");
  campoFantasia = createCheckbox("Gosta de fantasia?");
  campoAventura = createCheckbox("Gosta de aventura?");
}

function draw() {
  background("white");
  let idade = campoIdade.value();
  let gostaDeFantasia = campoFantasia.checked();
  let gostaDeAventura = campoAventura.checked();
  let recomendacao = geraRecomendacao(idade, gostaDeFantasia, gostaDeAventura);

  fill(color(76, 0, 115));
  textAlign(CENTER, CENTER);
  textSize(38);
  text(recomendacao, width / 2, height / 2);
}

function geraRecomendacao(idade, gostaDeFantasia, gostaDeAventura) {
  if (idade >= 10) {
    if (idade >= 14) {
      return "meu amigo totoro";
    } else {
      if (idade >= 12) {
        if(gostaDeFantasia || gostaDeAventura) {
          return "Homem aranha: no aranhaverso";          
        } else{
         return "vidas ao vento";
        }
      } else {
        if (gostaDeFantasia) {
          return "castelo animado";
        } else {
          return "os serviços de entrega da kiki";
        }
      }
    }
  } else {
    if (gostaDeFantasia) {
      return "digital circus";
    } else {
      return "a princesa kaguya";
    }
  }
}
